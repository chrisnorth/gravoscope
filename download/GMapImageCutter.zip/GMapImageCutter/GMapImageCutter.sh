#!/bin/sh
java -Xms512M -Xmx1024M -jar GMapImageCutter.jar
